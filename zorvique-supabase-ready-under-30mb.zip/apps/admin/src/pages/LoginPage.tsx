import { useState } from 'react';
import {
  ArrowLeft,
  ExternalLink,
  Eye,
  EyeOff,
  Lock,
  Mail,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export function LoginPage() {
  const {
    user,
    authError,
    authErrorDetails,
    signIn,
    registerOwnerEmail,
    resetPassword,
    resendVerification,
    reloadSession,
    logout,
    clearAuthError,
  } = useAuth();

  const [mode, setMode] = useState<'signin' | 'activate'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    setNotice(null);
    clearAuthError();

    if (!email.trim() || !password) {
      setLocalError('Enter your admin Gmail address and password.');
      return;
    }

    setSubmitting(true);
    try {
      if (mode === 'signin') {
        await signIn(email, password);
      } else {
        await registerOwnerEmail(email, password);
        setNotice(
          'Account registered! A verification link has been sent to your Gmail — open it, then click "I\'ve Verified — Refresh" or sign in.'
        );
        setMode('signin');
      }
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'Unable to sign in.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = async () => {
    setLocalError(null);
    setNotice(null);
    if (!email.trim()) {
      setLocalError('Enter your admin email above first to receive a password reset link.');
      return;
    }
    try {
      await resetPassword(email);
      setNotice('Password reset email sent. Check your Gmail inbox.');
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'Unable to send reset email.');
    }
  };

  const handleResendVerification = async () => {
    setLocalError(null);
    try {
      await resendVerification();
      setNotice('Verification link re-sent. Open your inbox to verify, then click Refresh.');
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'Unable to send verification email.');
    }
  };

  const handleRefreshSession = async () => {
    setLocalError(null);
    setRefreshing(true);
    try {
      await reloadSession();
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'Unable to refresh verification status.');
    } finally {
      setRefreshing(false);
    }
  };

  const displayError = authError || localError;
  const showConsoleSetup = Boolean(authErrorDetails?.needsConsoleEmailProvider && authErrorDetails.consoleUrl);

  return (
    <div className="min-h-screen bg-[#121212] text-[#E4E2E1] flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md space-y-4">
        <a
          href="/"
          className="inline-flex items-center gap-2 text-xs text-[#E0C0AF] hover:text-white transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Storefront</span>
        </a>

        <div className="rounded-2xl bg-[#1C1D1E] border border-white/10 p-8 sm:p-9 space-y-6">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="w-10 h-10 rounded-xl bg-[#FF7A00] text-[#121212] font-display font-bold text-base flex items-center justify-center shrink-0">
                Z
              </span>
              <div>
                <h1 className="font-display text-xl font-semibold text-white">Zorvique Admin</h1>
                <p className="text-xs text-[#E0C0AF]">Store Operations &amp; Control Center</p>
              </div>
            </div>
            <ShieldCheck className="w-5 h-5 text-[#FF7A00] shrink-0" aria-hidden="true" />
          </div>

          <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-[#141414] border border-white/10">
            <button
              type="button"
              onClick={() => {
                setMode('signin');
                setLocalError(null);
                clearAuthError();
              }}
              className={`min-h-[40px] py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                mode === 'signin' ? 'bg-[#262728] text-white' : 'text-[#E0C0AF] hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('activate');
                setLocalError(null);
                clearAuthError();
              }}
              className={`min-h-[40px] py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                mode === 'activate' ? 'bg-[#262728] text-white' : 'text-[#E0C0AF] hover:text-white'
              }`}
            >
              Admin Setup
            </button>
          </div>

          {mode === 'activate' && (
            <div className="rounded-xl bg-[#FF7A00]/10 border border-[#FF7A00]/25 px-3.5 py-2.5 text-[11px] text-[#F5B082] leading-relaxed">
              First-time password activation is locked to the Store Admin (<span className="font-semibold text-white">lessuse611@gmail.com</span>). Anyone added later can only join as a <span className="font-semibold text-white">Member</span> added by the Admin in Settings.
            </div>
          )}

          {displayError && (
            <div
              role="alert"
              className="rounded-xl bg-red-500/15 border border-red-500/30 p-4 text-xs text-red-200 space-y-3 leading-relaxed"
            >
              <p>{displayError}</p>

              {showConsoleSetup && authErrorDetails?.consoleUrl && (
                <div className="pt-2 border-t border-red-400/20 space-y-2.5 text-red-100/90">
                  <ol className="list-decimal pl-4 space-y-1">
                    <li>Open Firebase Authentication &rarr; Sign-in method</li>
                    <li>Click <strong>Email/Password</strong>, turn <strong>Enable</strong> ON, and Save</li>
                    <li>Return here and submit <strong>Activate Email Login</strong> (first time) or <strong>Sign In</strong></li>
                  </ol>
                  <a
                    href={authErrorDetails.consoleUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[38px] items-center gap-2 px-3.5 py-2 rounded-lg bg-white text-[#121212] hover:bg-neutral-100 font-semibold transition-colors"
                  >
                    <span>Open Firebase Sign-in Method</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}

              {user && !user.emailVerified && (
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    disabled={refreshing}
                    onClick={() => void handleRefreshSession()}
                    className="min-h-[36px] px-3 py-1.5 rounded-lg bg-[#FF7A00] text-[#121212] font-semibold inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
                    <span>{refreshing ? 'Checking...' : "I've Verified — Refresh"}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleResendVerification()}
                    className="min-h-[36px] px-3 py-1.5 rounded-lg bg-white text-[#121212] font-semibold cursor-pointer"
                  >
                    Resend Verification
                  </button>
                  <button
                    type="button"
                    onClick={() => void logout()}
                    className="min-h-[36px] px-3 py-1.5 rounded-lg border border-white/20 text-white cursor-pointer"
                  >
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          )}

          {notice && (
            <div
              role="status"
              className="rounded-xl bg-emerald-500/15 border border-emerald-500/30 p-3.5 text-xs text-emerald-200 leading-relaxed"
            >
              {notice}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="admin-email" className="block text-xs font-medium text-[#E0C0AF]">
                Admin or Member Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#E0C0AF]/60 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="lessuse611@gmail.com"
                  className="w-full min-h-[44px] pl-10 pr-4 py-2.5 rounded-xl bg-[#141414] border border-white/10 text-sm text-white placeholder:text-white/30 focus:border-[#FF7A00] outline-none"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="admin-password" className="block text-xs font-medium text-[#E0C0AF]">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-[#E0C0AF]/60 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full min-h-[44px] pl-10 pr-11 py-2.5 rounded-xl bg-[#141414] border border-white/10 text-sm text-white placeholder:text-white/30 focus:border-[#FF7A00] outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 min-w-[36px] min-h-[36px] flex items-center justify-center text-[#E0C0AF]/70 hover:text-white cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {mode === 'signin' && (
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => void handleReset()}
                  className="text-xs text-[#E0C0AF] hover:text-[#FF7A00] underline cursor-pointer"
                >
                  Forgot password?
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full min-h-[46px] px-6 py-2.5 rounded-xl bg-[#FF7A00] hover:bg-[#E65C00] text-[#121212] font-display font-semibold text-sm transition-colors disabled:opacity-50 cursor-pointer"
            >
              {submitting
                ? mode === 'signin'
                  ? 'Signing in...'
                  : 'Creating account...'
                : mode === 'signin'
                  ? 'Sign In to Admin'
                  : 'Create & Send Verification'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
