import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  User,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
} from 'firebase/auth';
import { FIREBASE_PROJECT_ID, auth } from '../data/firebase';
import { resolveAuthorizedAdminRole } from '../data/adminApi';
import {
  type AdminAuthErrorInfo,
  type ResolvedAdminRole,
  OWNER_EMAIL,
  isOwnerEmail,
  mapAdminAuthError,
} from '../utils/adminLogic';

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  isOwner: boolean;
  adminRole: ResolvedAdminRole;
  isAuthorized: boolean;
  authError: string | null;
  authErrorDetails: AdminAuthErrorInfo | null;
  signIn: (email: string, password: string) => Promise<void>;
  registerOwnerEmail: (email: string, password: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  resendVerification: () => Promise<void>;
  reloadSession: () => Promise<void>;
  clearAuthError: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [adminRole, setAdminRole] = useState<ResolvedAdminRole>(null);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [authErrorDetails, setAuthErrorDetails] = useState<AdminAuthErrorInfo | null>(null);

  const evaluateUser = useCallback(async (fbUser: User | null) => {
    if (!fbUser) {
      setUser(null);
      setAdminRole(null);
      setIsAuthorized(false);
      setLoading(false);
      return;
    }

    const email = (fbUser.email || '').toLowerCase();
    if (!fbUser.emailVerified) {
      setUser(fbUser);
      setAdminRole(null);
      setIsAuthorized(false);
      setAuthErrorDetails({
        message: `Your email (${email}) is not verified yet. Open the verification link sent to your inbox, then click "I've Verified — Refresh".`,
        needsConsoleEmailProvider: false,
      });
      setLoading(false);
      return;
    }

    try {
      const role = await resolveAuthorizedAdminRole(email);
      if (!role) {
        await signOut(auth);
        setUser(null);
        setAdminRole(null);
        setIsAuthorized(false);
        setAuthErrorDetails({
          message: `Access refused: ${email} is not authorized. Only the Store Admin (${OWNER_EMAIL}) or approved Members added by the Admin can access this panel.`,
          needsConsoleEmailProvider: false,
        });
      } else {
        setUser(fbUser);
        setAdminRole(role);
        setIsAuthorized(true);
        setAuthErrorDetails(null);
      }
    } catch (err) {
      await signOut(auth);
      setUser(null);
      setAdminRole(null);
      setIsAuthorized(false);
      setAuthErrorDetails(mapAdminAuthError(err, FIREBASE_PROJECT_ID));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (fbUser) => {
      void evaluateUser(fbUser);
    });
    return () => unsub();
  }, [evaluateUser]);

  const signIn = useCallback(async (email: string, password: string) => {
    setAuthErrorDetails(null);
    try {
      const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
      if (!cred.user.emailVerified) {
        setAuthErrorDetails({
          message:
            'Email address is not verified yet. Click "Resend Verification" below and confirm the link in your inbox.',
          needsConsoleEmailProvider: false,
        });
        return;
      }
      const role = await resolveAuthorizedAdminRole(cred.user.email || '');
      if (!role) {
        await signOut(auth);
        const info: AdminAuthErrorInfo = {
          message: `Access refused: only the Store Admin (${OWNER_EMAIL}) or approved Members added by the Admin can sign in.`,
          needsConsoleEmailProvider: false,
        };
        setAuthErrorDetails(info);
        throw new Error(info.message);
      }
    } catch (err) {
      const info = mapAdminAuthError(err, FIREBASE_PROJECT_ID);
      setAuthErrorDetails(info);
      throw new Error(info.message);
    }
  }, []);

  const registerOwnerEmail = useCallback(async (email: string, password: string) => {
    setAuthErrorDetails(null);
    const clean = email.trim().toLowerCase();
    if (!isOwnerEmail(clean)) {
      const info: AdminAuthErrorInfo = {
        message: `Account activation is restricted to the Store Admin (${OWNER_EMAIL}) only. Other users can only be added as Members by the Admin inside Settings → Team Members.`,
        needsConsoleEmailProvider: false,
      };
      setAuthErrorDetails(info);
      throw new Error(info.message);
    }
    try {
      const cred = await createUserWithEmailAndPassword(auth, clean, password);
      await sendEmailVerification(cred.user);
    } catch (err) {
      const info = mapAdminAuthError(err, FIREBASE_PROJECT_ID);
      setAuthErrorDetails(info);
      throw new Error(info.message);
    }
  }, []);

  const resetPassword = useCallback(async (email: string) => {
    setAuthErrorDetails(null);
    try {
      await sendPasswordResetEmail(auth, email.trim());
    } catch (err) {
      const info = mapAdminAuthError(err, FIREBASE_PROJECT_ID);
      setAuthErrorDetails(info);
      throw new Error(info.message);
    }
  }, []);

  const logout = useCallback(async () => {
    await signOut(auth);
    setUser(null);
    setAdminRole(null);
    setIsAuthorized(false);
    setAuthErrorDetails(null);
  }, []);

  const resendVerification = useCallback(async () => {
    if (auth.currentUser && !auth.currentUser.emailVerified) {
      await sendEmailVerification(auth.currentUser);
    }
  }, []);

  const reloadSession = useCallback(async () => {
    if (!auth.currentUser) return;
    await auth.currentUser.reload();
    await auth.currentUser.getIdToken(true);
    await evaluateUser(auth.currentUser);
  }, [evaluateUser]);

  const clearAuthError = useCallback(() => {
    setAuthErrorDetails(null);
  }, []);

  const isOwner = adminRole === 'owner' || isOwnerEmail(user?.email);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isOwner,
        adminRole,
        isAuthorized,
        authError: authErrorDetails?.message || null,
        authErrorDetails,
        signIn,
        registerOwnerEmail,
        resetPassword,
        logout,
        resendVerification,
        reloadSession,
        clearAuthError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
