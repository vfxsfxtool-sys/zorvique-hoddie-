import {
  collection,
  deleteDoc,
  deleteField,
  doc,
  getDoc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { db } from './firebase';
import { OperationType, handleFirestoreError } from './errors';
import type {
  AdminUser,
  CmsPage,
  Collection,
  CourierName,
  DiscountCode,
  HeroSlide,
  HomepageData,
  MediaAsset,
  Order,
  OrderStatus,
  PaymentStatus,
  Product,
  SiteSettings,
  Subscriber,
  Testimonial,
} from './types';
import {
  INITIAL_STUDIO_PRODUCTS,
  STUDIO_ASSET_PRESETS,
  STUDIO_COLLECTION_SEED,
  analyzeStudioMigrationState,
} from './initialCatalogMigration';
import {
  type ResolvedAdminRole,
  buildSampleHoodieSvgDataUrl,
  ensureUniqueSlug,
  isOwnerEmail,
  planOrderConfirmationStock,
  resolveAdminRole,
  timestampToMs,
  validateNewMemberEmail,
} from '../utils/adminLogic';

export const DEFAULT_ADMIN_SETTINGS: SiteSettings = {
  brandName: 'ZORVIQUE',
  logoUrl: '',
  colors: {
    primary: '#FF7A00',
    background: '#121212',
    surface: '#1F2020',
  },
  nav: [
    { label: 'Home', href: '/' },
    { label: 'Shop Hoodies', href: '/shop' },
    { label: 'Shipping', href: '/page/shipping-returns' },
    { label: 'Support', href: '/page/support' },
  ],
  footerLinks: [
    { label: 'Privacy Policy', href: '/page/privacy-policy' },
    { label: 'Terms of Service', href: '/page/terms-of-service' },
    { label: 'Support', href: '/page/support' },
  ],
  social: { instagram: '', facebook: '', tiktok: '', whatsapp: '03084540977' },
  announcement: '',
  shipping: {
    flatByCity: {
      Lahore: 200,
      Karachi: 300,
      Islamabad: 250,
      Rawalpindi: 250,
      Faisalabad: 250,
      Multan: 300,
      Peshawar: 350,
      Sialkot: 250,
      Gujranwala: 250,
      Quetta: 400,
      Other: 350,
    },
    freeThreshold: 12000,
  },
  payments: {
    cod: { enabled: true },
    jazzcash: {
      enabled: true,
      account: '0300-0000000 (Zorvique Studio)',
      instructions: 'Transfer the grand total to our JazzCash wallet and enter your TID below.',
    },
    easypaisa: {
      enabled: true,
      account: '0345-0000000 (Zorvique Studio)',
      instructions: 'Send exact total via EasyPaisa app and enter the 10-digit TID.',
    },
  },
  seo: {
    title: "Zorvique — Luxury Women's Hoodies Pakistan",
    description: 'Architectural fleece hoodies crafted in Pakistan for quiet luxury warmth.',
    ogImage: '',
  },
};

export const DEFAULT_ADMIN_HOMEPAGE: HomepageData = {
  heroMode: 'carousel',
  heroVideoUrl: '',
  heroPosterUrl: '',
  sections: [
    { id: 'hero', type: 'hero', visible: true, order: 0, title: 'Stand out Without trying.', body: '' },
    { id: 'collection', type: 'collection', visible: true, order: 1, title: 'Luxury Oversized Hoodies', body: 'Curated Collection' },
    { id: 'craft', type: 'craft', visible: true, order: 2, title: 'Craftsmanship', body: '' },
    { id: 'testimonials', type: 'testimonials', visible: true, order: 3, title: 'Loved Across Pakistan', body: '' },
    { id: 'newsletter', type: 'newsletter', visible: true, order: 4, title: 'Join the Zorvique Inner Circle', body: 'Subscribe for early drop access and private member releases.' },
  ],
  stats: [
    { value: '500+', label: 'GSM Heavyweight Fabric' },
    { value: '100%', label: 'Pre-shrunk Combed Cotton' },
  ],
  craft: {
    title: 'Engineered in Pakistan for Ultimate Comfort',
    body: 'Every Zorvique hoodie is cut from heavyweight long-staple cotton blends tailored for structured drape, thermal warmth, and effortless winter layering.',
    imageUrl: '',
  },
};

export async function ensureOwnerAdminRecord(email: string): Promise<void> {
  const clean = email.trim().toLowerCase();
  if (!isOwnerEmail(clean)) return;
  const refDoc = doc(db, 'admins', clean);
  try {
    const snap = await getDoc(refDoc);
    if (!snap.exists()) {
      await setDoc(refDoc, {
        role: 'owner',
        createdAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `admins/${clean}`);
  }
}

export async function resolveAuthorizedAdminRole(email: string): Promise<ResolvedAdminRole> {
  const normalized = email.trim().toLowerCase();
  if (isOwnerEmail(normalized)) {
    try {
      await ensureOwnerAdminRecord(normalized);
    } catch {
      // Owner identity remains authorized even if Firestore sync is transiently unavailable
    }
    return 'owner';
  }
  try {
    const snap = await getDoc(doc(db, 'admins', normalized));
    if (!snap.exists()) return null;
    const data = snap.data() as Partial<AdminUser>;
    return resolveAdminRole(normalized, data.role);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `admins/${normalized}`);
  }
}

export async function checkIsAuthorizedAdmin(email: string): Promise<boolean> {
  const role = await resolveAuthorizedAdminRole(email);
  return role !== null;
}

export async function fetchSiteSettings(): Promise<SiteSettings> {
  try {
    const snap = await getDoc(doc(db, 'siteSettings', 'main'));
    if (!snap.exists()) return DEFAULT_ADMIN_SETTINGS;
    const raw = snap.data() as Partial<SiteSettings>;
    return {
      ...DEFAULT_ADMIN_SETTINGS,
      ...raw,
      colors: { ...DEFAULT_ADMIN_SETTINGS.colors, ...(raw.colors || {}) },
      social: {
        ...DEFAULT_ADMIN_SETTINGS.social,
        ...(raw.social || {}),
        whatsapp: raw.social?.whatsapp?.trim() || DEFAULT_ADMIN_SETTINGS.social.whatsapp,
      },
      shipping: {
        ...DEFAULT_ADMIN_SETTINGS.shipping,
        ...(raw.shipping || {}),
        flatByCity: {
          ...DEFAULT_ADMIN_SETTINGS.shipping.flatByCity,
          ...(raw.shipping?.flatByCity || {}),
        },
      },
      payments: {
        cod: { ...DEFAULT_ADMIN_SETTINGS.payments.cod, ...(raw.payments?.cod || {}) },
        jazzcash: { ...DEFAULT_ADMIN_SETTINGS.payments.jazzcash, ...(raw.payments?.jazzcash || {}) },
        easypaisa: { ...DEFAULT_ADMIN_SETTINGS.payments.easypaisa, ...(raw.payments?.easypaisa || {}) },
      },
      seo: { ...DEFAULT_ADMIN_SETTINGS.seo, ...(raw.seo || {}) },
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'siteSettings/main');
  }
}

export async function saveSiteSettings(settings: SiteSettings): Promise<void> {
  try {
    await setDoc(doc(db, 'siteSettings', 'main'), settings);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'siteSettings/main');
  }
}

export async function fetchHomepage(): Promise<HomepageData> {
  try {
    const snap = await getDoc(doc(db, 'homepage', 'main'));
    if (!snap.exists()) return DEFAULT_ADMIN_HOMEPAGE;
    return { ...DEFAULT_ADMIN_HOMEPAGE, ...(snap.data() as Partial<HomepageData>) };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'homepage/main');
  }
}

export async function saveHomepage(homepage: HomepageData): Promise<void> {
  try {
    await setDoc(doc(db, 'homepage', 'main'), homepage);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'homepage/main');
  }
}

export async function fetchProducts(): Promise<Product[]> {
  try {
    const snap = await getDocs(collection(db, 'products'));
    return snap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Omit<Product, 'id'>) }))
      .sort((a, b) => timestampToMs(b.updatedAt) - timestampToMs(a.updatedAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'products');
  }
}

export async function saveProduct(
  product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>,
  existingId?: string,
  allProducts: Product[] = []
): Promise<string> {
  const cleanName = product.name.trim();
  const cleanSku = product.sku.trim();
  if (!cleanName || !cleanSku) {
    throw new Error('Product name and SKU are required.');
  }
  if (!Number.isFinite(product.price) || product.price < 0) {
    throw new Error('Product price must be a valid non-negative number.');
  }

  const id = existingId || `prod_${Date.now()}_${Math.floor(100 + Math.random() * 900)}`;
  const existingSlugs = allProducts.map((p) => p.slug);
  const current = existingId ? allProducts.find((p) => p.id === existingId) : undefined;
  const uniqueSlug = ensureUniqueSlug(product.slug || cleanName, existingSlugs, current?.slug);

  const normalizedSizes = product.sizes
    .map((s) => ({
      label: s.label.trim().toUpperCase(),
      stock: Math.max(0, Math.round(Number(s.stock) || 0)),
    }))
    .filter((s) => s.label.length > 0);

  const normalizedColourways = product.colourways.map((c) => ({
    name: c.name.trim() || 'Default Wash',
    hex: c.hex.trim() || '#18181B',
    images: c.images.map((u) => u.trim()).filter(Boolean),
  }));

  const hasValidRackOrder =
    typeof product.rackOrder === 'number' && Number.isFinite(product.rackOrder);

  const basePayload = {
    name: cleanName,
    slug: uniqueSlug,
    sku: cleanSku,
    description: product.description.trim(),
    fabric: product.fabric.trim(),
    price: Math.round(product.price),
    compareAtPrice:
      product.compareAtPrice && Number.isFinite(product.compareAtPrice) && product.compareAtPrice > 0
        ? Math.round(product.compareAtPrice)
        : null,
    badges: product.badges.map((b) => b.trim()).filter(Boolean),
    collectionId: product.collectionId.trim(),
    colourways: normalizedColourways,
    sizes: normalizedSizes,
    status: product.status,
    featured: Boolean(product.featured),
    showOnRack: product.showOnRack !== false,
    seoTitle: product.seoTitle.trim(),
    seoDescription: product.seoDescription.trim(),
    updatedAt: serverTimestamp(),
  };

  try {
    if (existingId && current) {
      await updateDoc(doc(db, 'products', existingId), {
        ...basePayload,
        rackOrder: hasValidRackOrder
          ? Math.max(0, Math.min(999, Math.round(product.rackOrder as number)))
          : deleteField(),
      });
    } else {
      await setDoc(doc(db, 'products', id), {
        ...basePayload,
        ...(hasValidRackOrder
          ? { rackOrder: Math.max(0, Math.min(999, Math.round(product.rackOrder as number))) }
          : {}),
        isSample: false,
        createdAt: serverTimestamp(),
      });
    }
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `products/${id}`);
  }
}

export async function duplicateProduct(source: Product, allProducts: Product[]): Promise<string> {
  const existingSlugs = allProducts.map((p) => p.slug);
  const copyName = `${source.name} (Copy)`;
  const uniqueSlug = ensureUniqueSlug(copyName, existingSlugs);
  const id = `prod_${Date.now()}_${Math.floor(100 + Math.random() * 900)}`;

  try {
    await setDoc(doc(db, 'products', id), {
      name: copyName,
      slug: uniqueSlug,
      sku: `${source.sku}-COPY`,
      description: source.description,
      fabric: source.fabric,
      price: source.price,
      compareAtPrice: source.compareAtPrice ?? null,
      badges: [...source.badges],
      collectionId: source.collectionId,
      colourways: source.colourways.map((c) => ({ ...c, images: [...c.images] })),
      sizes: source.sizes.map((s) => ({ ...s })),
      status: 'draft',
      featured: false,
      showOnRack: source.showOnRack ?? true,
      seoTitle: source.seoTitle,
      seoDescription: source.seoDescription,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `products/${id}`);
  }
}

export async function toggleProductStatus(id: string, status: 'draft' | 'published'): Promise<void> {
  try {
    await updateDoc(doc(db, 'products', id), {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `products/${id}`);
  }
}

export async function updateProductRackPlacement(
  id: string,
  patch: { showOnRack?: boolean; rackOrder?: number }
): Promise<void> {
  try {
    await updateDoc(doc(db, 'products', id), {
      ...patch,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `products/${id}`);
  }
}

export async function reorderRackProducts(ordered: Product[]): Promise<void> {
  try {
    const batch = writeBatch(db);
    ordered.forEach((product, idx) => {
      batch.update(doc(db, 'products', product.id), {
        showOnRack: true,
        rackOrder: idx,
        updatedAt: serverTimestamp(),
      });
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, 'products');
  }
}

export async function deleteProduct(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'products', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `products/${id}`);
  }
}

export async function fetchCollections(): Promise<Collection[]> {
  try {
    const snap = await getDocs(collection(db, 'collections'));
    return snap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Omit<Collection, 'id'>) }))
      .sort((a, b) => a.order - b.order);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'collections');
  }
}

export async function saveCollection(item: Omit<Collection, 'id'>, existingId?: string): Promise<string> {
  const id = existingId || `col_${Date.now()}_${Math.floor(100 + Math.random() * 900)}`;
  try {
    await setDoc(doc(db, 'collections', id), item);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `collections/${id}`);
  }
}

export async function deleteCollection(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'collections', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `collections/${id}`);
  }
}

export async function fetchHeroSlides(): Promise<HeroSlide[]> {
  try {
    const snap = await getDocs(collection(db, 'heroSlides'));
    return snap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Omit<HeroSlide, 'id'>) }))
      .sort((a, b) => a.order - b.order);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'heroSlides');
  }
}

export async function saveHeroSlide(slide: Omit<HeroSlide, 'id'>, existingId?: string): Promise<string> {
  const id = existingId || `slide_${Date.now()}_${Math.floor(100 + Math.random() * 900)}`;
  try {
    await setDoc(doc(db, 'heroSlides', id), slide);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `heroSlides/${id}`);
  }
}

export async function deleteHeroSlide(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'heroSlides', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `heroSlides/${id}`);
  }
}

export async function reorderHeroSlides(slides: HeroSlide[]): Promise<void> {
  try {
    const batch = writeBatch(db);
    slides.forEach((slide, idx) => {
      batch.update(doc(db, 'heroSlides', slide.id), { order: idx });
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, 'heroSlides');
  }
}

export async function fetchTestimonials(): Promise<Testimonial[]> {
  try {
    const snap = await getDocs(collection(db, 'testimonials'));
    return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Testimonial, 'id'>) }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'testimonials');
  }
}

export async function saveTestimonial(item: Omit<Testimonial, 'id'>, existingId?: string): Promise<string> {
  const id = existingId || `test_${Date.now()}_${Math.floor(100 + Math.random() * 900)}`;
  try {
    await setDoc(doc(db, 'testimonials', id), item);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `testimonials/${id}`);
  }
}

export async function deleteTestimonial(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'testimonials', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `testimonials/${id}`);
  }
}

export async function fetchPages(): Promise<CmsPage[]> {
  try {
    const snap = await getDocs(collection(db, 'pages'));
    return snap.docs.map((d) => ({ slug: d.id, ...(d.data() as Omit<CmsPage, 'slug'>) }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'pages');
  }
}

export async function savePage(page: CmsPage): Promise<void> {
  try {
    await setDoc(doc(db, 'pages', page.slug), {
      title: page.title,
      body: page.body,
      visible: page.visible,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `pages/${page.slug}`);
  }
}

export async function deletePage(slug: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'pages', slug));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `pages/${slug}`);
  }
}

export async function fetchOrders(): Promise<Order[]> {
  try {
    const snap = await getDocs(collection(db, 'orders'));
    return snap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Omit<Order, 'id'>) }))
      .sort((a, b) => timestampToMs(b.createdAt) - timestampToMs(a.createdAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'orders');
  }
}

export async function updateOrderAtomic(
  order: Order,
  patch: {
    status: OrderStatus;
    paymentStatus: PaymentStatus;
    courier: CourierName;
    trackingNo: string;
    transactionId: string;
  }
): Promise<void> {
  const needsConfirmationTx = patch.status === 'confirmed' && order.status !== 'confirmed';
  const orderRef = doc(db, 'orders', order.id);
  const trackingRef = doc(db, 'orderTracking', order.orderNo);

  const buildBackfillTracking = (srcOrder: Order) => ({
    orderNo: srcOrder.orderNo,
    orderId: srcOrder.id,
    city: srcOrder.customer.city,
    itemCount: srcOrder.items.reduce((sum, item) => sum + Math.max(1, item.qty), 0),
    itemSummary: srcOrder.items.slice(0, 30).map((item) => ({
      name: item.name,
      size: item.size,
      colour: item.colour,
      qty: item.qty,
    })),
    total: srcOrder.total,
    paymentMethod: srcOrder.paymentMethod,
    paymentStatus: patch.paymentStatus,
    status: patch.status,
    courier: patch.courier,
    trackingNo: patch.trackingNo,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  if (!needsConfirmationTx) {
    try {
      await runTransaction(db, async (tx) => {
        const trackingSnap = await tx.get(trackingRef);
        tx.update(orderRef, patch);
        if (trackingSnap.exists()) {
          tx.update(trackingRef, {
            status: patch.status,
            paymentStatus: patch.paymentStatus,
            courier: patch.courier,
            trackingNo: patch.trackingNo,
            updatedAt: serverTimestamp(),
          });
        } else {
          tx.set(trackingRef, buildBackfillTracking(order));
        }
      });
      return;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${order.id}`);
    }
  }

  try {
    await runTransaction(db, async (tx) => {
      const freshOrderSnap = await tx.get(orderRef);
      if (!freshOrderSnap.exists()) {
        throw new Error('Order no longer exists.');
      }
      const freshOrder = { id: freshOrderSnap.id, ...(freshOrderSnap.data() as Omit<Order, 'id'>) };
      const freshTrackingRef = doc(db, 'orderTracking', freshOrder.orderNo);
      const trackingSnap = await tx.get(freshTrackingRef);

      if (freshOrder.status === 'confirmed') {
        tx.update(orderRef, patch);
        if (trackingSnap.exists()) {
          tx.update(freshTrackingRef, {
            status: patch.status,
            paymentStatus: patch.paymentStatus,
            courier: patch.courier,
            trackingNo: patch.trackingNo,
            updatedAt: serverTimestamp(),
          });
        } else {
          tx.set(freshTrackingRef, buildBackfillTracking(freshOrder));
        }
        return;
      }

      const uniqueProductIds = Array.from(new Set(freshOrder.items.map((i) => i.productId)));
      const productsById = new Map<string, Product>();
      for (const pid of uniqueProductIds) {
        const pSnap = await tx.get(doc(db, 'products', pid));
        if (pSnap.exists()) {
          productsById.set(pid, { id: pSnap.id, ...(pSnap.data() as Omit<Product, 'id'>) });
        }
      }

      const discountRef = freshOrder.discountCode
        ? doc(db, 'discountCodes', freshOrder.discountCode.toUpperCase())
        : null;
      const discountSnap = discountRef ? await tx.get(discountRef) : null;

      const stockPlan = planOrderConfirmationStock(freshOrder, productsById);
      if (!stockPlan.ok) {
        throw new Error(stockPlan.reason);
      }

      for (const [pid, newSizes] of stockPlan.updatedSizesByProductId.entries()) {
        tx.update(doc(db, 'products', pid), {
          sizes: newSizes,
          updatedAt: serverTimestamp(),
        });
      }

      if (discountRef && discountSnap?.exists()) {
        const dData = discountSnap.data() as Omit<DiscountCode, 'code'>;
        tx.update(discountRef, {
          usedCount: (dData.usedCount || 0) + 1,
        });
      }

      tx.update(orderRef, patch);
      if (trackingSnap.exists()) {
        tx.update(freshTrackingRef, {
          status: patch.status,
          paymentStatus: patch.paymentStatus,
          courier: patch.courier,
          trackingNo: patch.trackingNo,
          updatedAt: serverTimestamp(),
        });
      } else {
        tx.set(freshTrackingRef, buildBackfillTracking(freshOrder));
      }
    });
  } catch (error) {
    if (error instanceof Error && (error.message.includes('Insufficient stock') || error.message.includes('not found'))) {
      throw error;
    }
    handleFirestoreError(error, OperationType.UPDATE, `orders/${order.id}`);
  }
}

export async function fetchDiscountCodes(): Promise<DiscountCode[]> {
  try {
    const snap = await getDocs(collection(db, 'discountCodes'));
    return snap.docs.map((d) => ({ code: d.id, ...(d.data() as Omit<DiscountCode, 'code'>) }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'discountCodes');
  }
}

export async function saveDiscountCode(item: DiscountCode): Promise<void> {
  const code = item.code.trim().toUpperCase();
  try {
    await setDoc(doc(db, 'discountCodes', code), {
      percent: item.percent,
      usageLimit: item.usageLimit,
      usedCount: item.usedCount,
      expiresAt: item.expiresAt || null,
      active: item.active,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `discountCodes/${code}`);
  }
}

export async function deleteDiscountCode(code: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'discountCodes', code));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `discountCodes/${code}`);
  }
}

export async function fetchSubscribers(): Promise<Subscriber[]> {
  try {
    const snap = await getDocs(collection(db, 'subscribers'));
    return snap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Omit<Subscriber, 'id'>) }))
      .sort((a, b) => timestampToMs(b.createdAt) - timestampToMs(a.createdAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'subscribers');
  }
}

export async function deleteSubscriber(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'subscribers', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `subscribers/${id}`);
  }
}

export async function fetchMediaAssets(): Promise<MediaAsset[]> {
  try {
    const snap = await getDocs(collection(db, 'media'));
    return snap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Omit<MediaAsset, 'id'>) }))
      .sort((a, b) => timestampToMs(b.createdAt) - timestampToMs(a.createdAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'media');
  }
}

export async function registerMediaUrl(input: {
  name?: string;
  url: string;
  contentType?: string;
}): Promise<MediaAsset> {
  const url = input.url.trim();
  if (!url) {
    throw new Error('Enter a valid image or video path/URL.');
  }
  const isValidUrl = url.startsWith('/') || /^https?:\/\//i.test(url);
  if (!isValidUrl) {
    throw new Error('Use an https:// image URL or a static path like /assets/rack/rack_obsidian.jpg.');
  }

  const inferredName =
    input.name?.trim() ||
    url.split('?')[0].split('/').filter(Boolean).pop() ||
    'Studio Asset';
  const cleanName = inferredName.slice(0, 200);
  const inferredVideo = /\.(mp4|webm|mov)(\?|$)/i.test(url);
  const contentType = input.contentType?.trim() || (inferredVideo ? 'video/mp4' : 'image/jpeg');

  const mediaId = `med_${Date.now()}_${Math.floor(100 + Math.random() * 900)}`;
  const record: Omit<MediaAsset, 'id'> = {
    name: cleanName,
    url,
    storagePath: 'url-asset',
    contentType,
    size: 0,
    createdAt: serverTimestamp(),
  };

  try {
    await setDoc(doc(db, 'media', mediaId), record);
    return { id: mediaId, ...record, createdAt: Date.now() };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `media/${mediaId}`);
  }
}

export async function importStudioMediaPresets(existingMedia: MediaAsset[]): Promise<number> {
  const existingUrls = new Set(existingMedia.map((m) => m.url.trim()));
  const missing = STUDIO_ASSET_PRESETS.filter((preset) => !existingUrls.has(preset.url));
  if (missing.length === 0) return 0;

  const batch = writeBatch(db);
  missing.forEach((preset, idx) => {
    const mediaId = `med_${preset.id.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    batch.set(doc(db, 'media', mediaId), {
      name: `${preset.label} Hoodie`,
      url: preset.url,
      storagePath: 'static-asset',
      contentType: 'image/jpeg',
      size: 0,
      createdAt: serverTimestamp(),
    });
    void idx;
  });

  try {
    await batch.commit();
    return missing.length;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'media');
  }
}

export async function deleteMediaRecord(asset: MediaAsset): Promise<void> {
  try {
    await deleteDoc(doc(db, 'media', asset.id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `media/${asset.id}`);
  }
}

export async function fetchAdmins(): Promise<AdminUser[]> {
  try {
    const snap = await getDocs(collection(db, 'admins'));
    return snap.docs.map((d) => ({ email: d.id, ...(d.data() as Omit<AdminUser, 'email'>) }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'admins');
  }
}

export async function addAdminEmail(email: string): Promise<void> {
  const check = validateNewMemberEmail(email);
  if (check.ok === false) {
    throw new Error(check.reason);
  }
  try {
    await setDoc(doc(db, 'admins', check.email), {
      role: 'member',
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `admins/${check.email}`);
  }
}

export async function removeAdminEmail(email: string): Promise<void> {
  const clean = email.trim().toLowerCase();
  if (isOwnerEmail(clean)) {
    throw new Error('The primary Store Admin (Owner) account cannot be removed.');
  }
  try {
    await deleteDoc(doc(db, 'admins', clean));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `admins/${clean}`);
  }
}

export async function loadSampleData(): Promise<void> {
  const batch = writeBatch(db);

  batch.set(doc(db, 'siteSettings', 'main'), DEFAULT_ADMIN_SETTINGS);
  batch.set(doc(db, 'homepage', 'main'), DEFAULT_ADMIN_HOMEPAGE);

  batch.set(doc(db, 'collections', 'sample_col_heavyweight'), {
    name: 'Heavyweight Fleece',
    slug: 'heavyweight-fleece',
    order: 0,
    visible: true,
    isSample: true,
  });
  batch.set(doc(db, 'collections', 'sample_col_limited'), {
    name: 'Limited Edition',
    slug: 'limited-edition',
    order: 1,
    visible: true,
    isSample: true,
  });

  const sampleProducts = [
    {
      id: 'sample_prod_amber',
      name: '[SAMPLE] Amber Frost Oversized',
      slug: 'sample-amber-frost-oversized',
      sku: 'ZRV-SMP-01',
      description: 'Sample 450 GSM French terry hoodie with double-lined architectural hood and dropped shoulder.',
      fabric: '450 GSM Heavyweight Fleece · Pre-shrunk Cotton',
      price: 12500,
      compareAtPrice: 15000,
      badges: ['SAMPLE', 'Bestseller'],
      collectionId: 'sample_col_heavyweight',
      colourways: [
        {
          name: 'Sunset Amber',
          hex: '#FF7A00',
          images: [buildSampleHoodieSvgDataUrl('#8D420B', '#D96B16', 'SAMPLE · AMBER FROST')],
        },
        {
          name: 'Obsidian',
          hex: '#1C1C1E',
          images: [buildSampleHoodieSvgDataUrl('#1C1C1E', '#2D2D30', 'SAMPLE · OBSIDIAN')],
        },
      ],
      sizes: [
        { label: 'S', stock: 8 },
        { label: 'M', stock: 12 },
        { label: 'L', stock: 10 },
        { label: 'XL', stock: 4 },
      ],
      status: 'published',
      featured: true,
      seoTitle: 'Amber Frost Oversized Hoodie — Zorvique',
      seoDescription: 'Sample luxury women oversized hoodie in Sunset Amber.',
      isSample: true,
    },
    {
      id: 'sample_prod_obsidian',
      name: '[SAMPLE] Obsidian Black Heavyweight',
      slug: 'sample-obsidian-black-heavyweight',
      sku: 'ZRV-SMP-02',
      description: 'Sample 500 GSM heavyweight obsidian cotton fleece crafted for brisk Lahore and Islamabad evenings.',
      fabric: '500 GSM French Terry Cotton',
      price: 13500,
      compareAtPrice: 15500,
      badges: ['SAMPLE', 'New Drop'],
      collectionId: 'sample_col_heavyweight',
      colourways: [
        {
          name: 'Obsidian Black',
          hex: '#19191B',
          images: [buildSampleHoodieSvgDataUrl('#18181A', '#2C2C30', 'SAMPLE · OBSIDIAN BLACK')],
        },
      ],
      sizes: [
        { label: 'S', stock: 6 },
        { label: 'M', stock: 10 },
        { label: 'L', stock: 8 },
        { label: 'XL', stock: 5 },
      ],
      status: 'published',
      featured: true,
      seoTitle: 'Obsidian Black Heavyweight — Zorvique',
      seoDescription: 'Sample 500 GSM obsidian fleece hoodie.',
      isSample: true,
    },
    {
      id: 'sample_prod_pine',
      name: '[SAMPLE] Pine Forest Oversized',
      slug: 'sample-pine-forest-oversized',
      sku: 'ZRV-SMP-03',
      description: 'Sample brushed interior fleece hoodie in deep pine green with relaxed silhouette.',
      fabric: 'Brushed Interior Fleece · Drop Shoulder',
      price: 12900,
      compareAtPrice: null,
      badges: ['SAMPLE'],
      collectionId: 'sample_col_limited',
      colourways: [
        {
          name: 'Pine Forest',
          hex: '#1E4631',
          images: [buildSampleHoodieSvgDataUrl('#132E20', '#23593D', 'SAMPLE · PINE FOREST')],
        },
      ],
      sizes: [
        { label: 'S', stock: 4 },
        { label: 'M', stock: 9 },
        { label: 'L', stock: 7 },
        { label: 'XL', stock: 3 },
      ],
      status: 'published',
      featured: false,
      seoTitle: 'Pine Forest Oversized — Zorvique',
      seoDescription: 'Sample deep pine oversized women hoodie.',
      isSample: true,
    },
    {
      id: 'sample_prod_sahara',
      name: '[SAMPLE] Sahara Sand Essential',
      slug: 'sample-sahara-sand-essential',
      sku: 'ZRV-SMP-04',
      description: 'Sample warm sand cotton blend essential hoodie tailored for clean everyday layering.',
      fabric: 'Soft Cotton Blend · Relaxed Cut',
      price: 11900,
      compareAtPrice: null,
      badges: ['SAMPLE', 'Trending'],
      collectionId: 'sample_col_limited',
      colourways: [
        {
          name: 'Sahara Sand',
          hex: '#CBB89D',
          images: [buildSampleHoodieSvgDataUrl('#594C3B', '#CBB89D', 'SAMPLE · SAHARA SAND')],
        },
      ],
      sizes: [
        { label: 'S', stock: 7 },
        { label: 'M', stock: 11 },
        { label: 'L', stock: 6 },
        { label: 'XL', stock: 4 },
      ],
      status: 'published',
      featured: false,
      seoTitle: 'Sahara Sand Essential — Zorvique',
      seoDescription: 'Sample sahara sand women hoodie.',
      isSample: true,
    },
  ];

  for (const p of sampleProducts) {
    batch.set(doc(db, 'products', p.id), {
      ...p,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }

  const sampleSlides = [
    {
      id: 'sample_slide_1',
      order: 0,
      productId: 'sample_prod_amber',
      colourName: 'Sunset Amber',
      bgColor: '#B8540D',
      headline: 'Stand out Without trying.',
      body: 'Designed to elevate even the simplest outfit, this oversized fleece hoodie wraps you in lightweight thermal luxury.',
      ctaLabel: 'Get the look',
      ctaLink: '/product/sample-amber-frost-oversized',
      imageUrl: buildSampleHoodieSvgDataUrl('#B8540D', '#E66D15', 'AMBER FROST'),
      active: true,
      isSample: true,
    },
    {
      id: 'sample_slide_2',
      order: 1,
      productId: 'sample_prod_obsidian',
      colourName: 'Obsidian Black',
      bgColor: '#1E1F21',
      headline: 'Stand out Without trying.',
      body: '500 GSM French terry milled for structured drape, crisp cuff retention, and quiet studio minimalism.',
      ctaLabel: 'Get the look',
      ctaLink: '/product/sample-obsidian-black-heavyweight',
      imageUrl: buildSampleHoodieSvgDataUrl('#1E1F21', '#2D2E32', 'OBSIDIAN BLACK'),
      active: true,
      isSample: true,
    },
    {
      id: 'sample_slide_3',
      order: 2,
      productId: 'sample_prod_pine',
      colourName: 'Pine Forest',
      bgColor: '#173A28',
      headline: 'Stand out Without trying.',
      body: 'Brushed interior fleece in deep botanical pine tailored for effortless winter evenings across Pakistan.',
      ctaLabel: 'Get the look',
      ctaLink: '/product/sample-pine-forest-oversized',
      imageUrl: buildSampleHoodieSvgDataUrl('#173A28', '#255E41', 'PINE FOREST'),
      active: true,
      isSample: true,
    },
  ];

  for (const s of sampleSlides) {
    batch.set(doc(db, 'heroSlides', s.id), s);
  }

  const sampleTestimonials = [
    {
      id: 'sample_test_1',
      name: 'Ayesha Khan',
      city: 'Lahore',
      rating: 5,
      text: 'The weight of this fleece rivals luxury houses. Wore it in Islamabad winter and stayed effortlessly warm.',
      visible: true,
      isSample: true,
    },
    {
      id: 'sample_test_2',
      name: 'Hira Malik',
      city: 'Karachi',
      rating: 5,
      text: 'Oversized fit is absolute perfection. Heavy fabric that holds the hood structure after washing.',
      visible: true,
      isSample: true,
    },
    {
      id: 'sample_test_3',
      name: 'Zainab Tariq',
      city: 'Islamabad',
      rating: 5,
      text: 'Fast TCS delivery and clean packaging. The Sunset Amber shade looks extraordinary in person.',
      visible: true,
      isSample: true,
    },
  ];

  for (const t of sampleTestimonials) {
    batch.set(doc(db, 'testimonials', t.id), t);
  }

  batch.set(doc(db, 'pages', 'privacy-policy'), {
    title: 'Privacy Policy',
    body: '# Zorvique Privacy Policy\n\nWe collect only the customer contact and shipping details needed to dispatch your order across Pakistan.',
    visible: true,
  });
  batch.set(doc(db, 'pages', 'terms-of-service'), {
    title: 'Terms of Service',
    body: '# Terms of Service\n\nAll prices are listed in PKR. Orders ship nationwide via TCS, Leopard, or Trax.',
    visible: true,
  });
  batch.set(doc(db, 'pages', 'shipping-returns'), {
    title: 'Shipping & Returns',
    body: '# Shipping & Returns\n\n## Dispatch\nOrders placed before 2 PM PKT dispatch the same business day from our Lahore studio.\n\n## Exchanges\nUnused garments with tags intact may be exchanged within 7 days.',
    visible: true,
  });
  batch.set(doc(db, 'pages', 'support'), {
    title: 'Customer Support',
    body: '# Zorvique Support\n\nReach our Lahore studio team Monday to Saturday, 10 AM – 7 PM PKT.',
    visible: true,
  });

  batch.set(doc(db, 'discountCodes', 'ZORVIQUE10'), {
    percent: 10,
    usageLimit: 100,
    usedCount: 0,
    expiresAt: null,
    active: true,
  });

  try {
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'sample-data');
  }
}

export async function deleteAllSampleData(): Promise<number> {
  const targets = ['products', 'heroSlides', 'collections', 'testimonials'] as const;
  let removed = 0;

  try {
    const batch = writeBatch(db);
    for (const colName of targets) {
      const snap = await getDocs(query(collection(db, colName), where('isSample', '==', true)));
      snap.docs.forEach((d) => {
        batch.delete(d.ref);
        removed += 1;
      });
    }
    await batch.commit();
    return removed;
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, 'sample-data');
  }
}

export async function repairPlaceholderStudioImages(existingProducts: Product[]): Promise<number> {
  const { svgPlaceholderProducts } = analyzeStudioMigrationState(existingProducts);
  if (svgPlaceholderProducts.length === 0) return 0;

  const batch = writeBatch(db);
  for (const { existing, seed } of svgPlaceholderProducts) {
    const updatedColourways =
      existing.colourways.length > 0
        ? existing.colourways.map((cw, idx) => {
            const firstImg = cw.images?.[0]?.trim() || '';
            if (idx === 0 && (!firstImg || firstImg.startsWith('data:image/svg+xml'))) {
              return { ...cw, images: seed.colourways[0].images };
            }
            return cw;
          })
        : seed.colourways;

    batch.update(doc(db, 'products', existing.id), {
      colourways: updatedColourways,
      updatedAt: serverTimestamp(),
    });
  }

  try {
    await batch.commit();
    return svgPlaceholderProducts.length;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, 'studio-placeholder-repair');
  }
}

export async function importStudioCatalog(existingProducts?: Product[]): Promise<{
  createdCount: number;
  repairedCount: number;
}> {
  const currentProducts = existingProducts ?? (await fetchProducts());
  const { missingSeeds, svgPlaceholderProducts } = analyzeStudioMigrationState(currentProducts);

  const batch = writeBatch(db);

  batch.set(doc(db, 'collections', STUDIO_COLLECTION_SEED.id), {
    name: STUDIO_COLLECTION_SEED.name,
    slug: STUDIO_COLLECTION_SEED.slug,
    order: STUDIO_COLLECTION_SEED.order,
    visible: STUDIO_COLLECTION_SEED.visible,
    isSample: STUDIO_COLLECTION_SEED.isSample,
  });

  const seedsToWrite =
    currentProducts.length === 0 ? INITIAL_STUDIO_PRODUCTS : missingSeeds;

  for (const item of seedsToWrite) {
    batch.set(doc(db, 'products', item.id), {
      name: item.name,
      slug: item.slug,
      sku: item.sku,
      description: item.description,
      fabric: item.fabric,
      price: item.price,
      compareAtPrice: item.compareAtPrice,
      badges: item.badges,
      collectionId: item.collectionId,
      colourways: item.colourways,
      sizes: item.sizes,
      status: item.status,
      featured: item.featured,
      showOnRack: item.showOnRack,
      rackOrder: item.rackOrder,
      seoTitle: item.seoTitle,
      seoDescription: item.seoDescription,
      isSample: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }

  if (currentProducts.length > 0) {
    for (const { existing, seed } of svgPlaceholderProducts) {
      const updatedColourways =
        existing.colourways.length > 0
          ? existing.colourways.map((cw, idx) => {
              const firstImg = cw.images?.[0]?.trim() || '';
              if (idx === 0 && (!firstImg || firstImg.startsWith('data:image/svg+xml'))) {
                return { ...cw, images: seed.colourways[0].images };
              }
              return cw;
            })
          : seed.colourways;

      batch.update(doc(db, 'products', existing.id), {
        colourways: updatedColourways,
        updatedAt: serverTimestamp(),
      });
    }
  }

  try {
    await batch.commit();
    return {
      createdCount: seedsToWrite.length,
      repairedCount: currentProducts.length === 0 ? 0 : svgPlaceholderProducts.length,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'studio-catalog-import');
  }
}
